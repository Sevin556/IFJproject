#include <stdio.h>
#include "parser.h"
#include "err_code.h"
#include "instruction-list.h"

tSymtable gTable;               // globalna tabulka
tSymtable lTable;               // lokalni tabulka
tDLListInst instList;

int main(int argc, char **argv) {
    (void)argv;
    if(argc > 1) {
        fprintf(stderr, "Program nesmi být volán s parametry");
        return ERR_INTERN;
    }

    int rett = OK;
    symTableInit(&gTable);
    symTableInit(&lTable);
    DLInitList(&instList);
    symTableInsertVesFunction(&gTable);

    rett = parse();

    instructionPrinter(&instList);
    DLDisposeList(&instList);
    symTableDispose(&gTable);
    symTableDispose(&lTable);

    return rett;
}